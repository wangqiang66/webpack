window.wx = {
    getSystemInfoSync:()=>{
        return {
            windowHeight:600,
            windowWidth:340
        }
    }
}