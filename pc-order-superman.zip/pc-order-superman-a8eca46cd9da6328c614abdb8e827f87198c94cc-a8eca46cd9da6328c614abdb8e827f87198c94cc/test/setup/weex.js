window.weex = {
    requireModule() {
        return {}
    }
}
