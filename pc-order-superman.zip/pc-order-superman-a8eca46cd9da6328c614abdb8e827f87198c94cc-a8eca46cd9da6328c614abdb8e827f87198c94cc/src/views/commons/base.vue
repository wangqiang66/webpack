<!--
  function: base
  author  : wq
  update  : 2018/9/26 17:17
-->
<script>
import SearchList from '@/components/searchList'
export default {
  name: 'base',
  render () {
    return (
      <SearchList></SearchList>
    )
  }
}
</script>
