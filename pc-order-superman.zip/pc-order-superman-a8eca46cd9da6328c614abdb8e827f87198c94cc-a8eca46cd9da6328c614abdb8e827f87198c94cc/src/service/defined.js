/**
 * function: defined
 * author  : wq
 * update  : 2018/9/19 9:14
 */
export { Login, UserInfo } from './modules/user/defined'
