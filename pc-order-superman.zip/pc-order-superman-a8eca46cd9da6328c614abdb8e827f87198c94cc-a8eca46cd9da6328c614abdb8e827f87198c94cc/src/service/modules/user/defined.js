/**
 * function: defined
 * author  : wq
 * update  : 2018/9/18 16:45
 */
export const Login = '/user/login'
export const UserInfo = '/user/info'
