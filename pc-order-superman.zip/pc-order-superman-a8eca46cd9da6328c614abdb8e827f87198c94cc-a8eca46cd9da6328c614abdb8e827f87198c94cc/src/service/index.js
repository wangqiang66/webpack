/**
 * function: index
 * author  : wq
 * update  : 2018/9/14 16:03
 */
export { loginByUsername, logout, getUserInfo } from './modules/user/user'

// const api = Object.assign({}, user)
// for (let i in api) {
//   if (api.hasOwnProperty(i)) {
//     exports[i] = api[i]
//   }
// }
