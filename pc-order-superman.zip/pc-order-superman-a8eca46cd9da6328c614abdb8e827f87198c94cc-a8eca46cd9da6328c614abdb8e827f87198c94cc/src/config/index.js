/**
 * function: index
 * author  : wq
 * update  : 2018/9/5 9:54
 */

const AppConfig = {
  debug: true
}

export default AppConfig
