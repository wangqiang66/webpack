/**
 * 路由路径的定义
 */
export const Root = '/'
export const Login = '/login'
export const Home = '/home'
export const UserInfo = '/user/info'
